module Main where

import           Lib
import           System.IO
import           Data.List

main = do
    contents <- readFile "../../Downloads/EXPORT.CSV"
    putStrLn $ handleFileContents contents


handleFileContents :: String -> String
handleFileContents contents =
    let debitsIndex = words (head tableRows) in show debitsIndex
    where tableRows = lines contents

splitAtCommas :: String -> [String]
splitAtCommas = splitOn ","


